<?php
session_start();
require_once 'includes/db.php';

// ── AJAX: add to cart ──────────────────────────────────────────────
if (isset($_GET['action']) && $_GET['action'] === 'add') {
    $id    = (int)$_GET['id'];
    $name  = htmlspecialchars(trim($_GET['name']  ?? ''));
    $price = (float)$_GET['price'];
    $qty   = max(1, (int)($_GET['qty'] ?? 1));

    if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
    if (isset($_SESSION['cart'][$id])) {
        $_SESSION['cart'][$id] += $qty;
    } else {
        $_SESSION['cart'][$id] = $qty;
    }
    $count = array_sum($_SESSION['cart']);
    header('Content-Type: application/json');
    echo json_encode(['count' => $count, 'success' => true]);
    exit;
}

// ── Remove item ────────────────────────────────────────────────────
if (isset($_GET['remove'])) {
    unset($_SESSION['cart'][(int)$_GET['remove']]);
    header("Location: cart.php");
    exit;
}

// ── Update quantities ──────────────────────────────────────────────
if (isset($_POST['update_cart'])) {
    foreach ($_POST['qty'] as $id => $qty) {
        $qty = (int)$qty;
        if ($qty <= 0) unset($_SESSION['cart'][$id]);
        else           $_SESSION['cart'][$id] = $qty;
    }
    header("Location: cart.php");
    exit;
}

// ── Checkout ───────────────────────────────────────────────────────
if (isset($_POST['checkout'])) {
    $cname = htmlspecialchars(trim($_POST['cname'] ?? 'Guest'));
    $email = htmlspecialchars(trim($_POST['email'] ?? ''));
    if (!empty($_SESSION['cart'])) {
        $total = 0;
        $items = [];
        foreach ($_SESSION['cart'] as $id => $qty) {
            $product = $pdo->prepare("SELECT * FROM products WHERE id = ?");
            $product->execute([$id]);
            $product = $product->fetch();
            if ($product) {
                $total  += $product['price'] * $qty;
                $items[] = ['product' => $product, 'qty' => $qty];
            }
        }
        $stmt = $pdo->prepare("INSERT INTO orders (name, email, total) VALUES (?,?,?)");
        $stmt->execute([$cname, $email, $total]);
        $order_id = $pdo->lastInsertId();

        foreach ($items as $item) {
            $stmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?,?,?,?)");
            $stmt->execute([$order_id, $item['product']['id'], $item['qty'], $item['product']['price']]);
        }
        unset($_SESSION['cart']);
        header("Location: orders.php?success=1");
        exit;
    }
}

// ── Build cart for display ─────────────────────────────────────────
$cart_items = [];
$total = 0;
if (!empty($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $id => $qty) {
        $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->execute([$id]);
        $product = $stmt->fetch();
        if ($product) {
            $cart_items[] = ['product' => $product, 'qty' => $qty];
            $total += $product['price'] * $qty;
        }
    }
}
$cart_count = array_sum($_SESSION['cart'] ?? []);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart – Estore</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<nav class="navbar">
    <a href="index.php" class="nav-logo">🛍 Estore</a>
    <div class="nav-right">
        <a href="cart.php" class="btn-cart">🛒 Cart <span class="cart-badge"><?= $cart_count ?></span></a>
    </div>
</nav>
<div class="nav-spacer"></div>

<div class="container">
    <a href="index.php" class="back-link">← Continue Shopping</a>
    <h2 class="page-title">Your Cart</h2>

    <?php if (empty($cart_items)): ?>
        <div class="empty-state">
            <p>Your cart is empty.</p>
            <a href="index.php" class="btn-primary">Browse Products</a>
        </div>
    <?php else: ?>
    <div class="cart-layout">
        <div class="cart-left">
            <form action="cart.php" method="post">
                <table class="cart-table">
                    <thead>
                        <tr><th>Product</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th></th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td class="cart-product-name">
                                <?php if ($item['product']['image']): ?>
                                    <img src="<?= htmlspecialchars($item['product']['image']) ?>" alt="">
                                <?php endif; ?>
                                <?= htmlspecialchars($item['product']['name']) ?>
                            </td>
                            <td>$<?= number_format($item['product']['price'], 2) ?></td>
                            <td>
                                <input type="number" name="qty[<?= $item['product']['id'] ?>]"
                                       value="<?= $item['qty'] ?>" min="0" class="qty-input">
                            </td>
                            <td>$<?= number_format($item['product']['price'] * $item['qty'], 2) ?></td>
                            <td><a href="cart.php?remove=<?= $item['product']['id'] ?>" class="remove-link">✕</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="cart-update-row">
                    <button type="submit" name="update_cart" class="btn-secondary">Update Cart</button>
                </div>
            </form>
        </div>

        <div class="cart-summary-box">
            <h3>Order Summary</h3>
            <div class="summary-row"><span>Subtotal</span><span>$<?= number_format($total, 2) ?></span></div>
            <div class="summary-row"><span>Shipping</span><span class="free-tag">Free</span></div>
            <div class="summary-row total-row"><span>Total</span><span>$<?= number_format($total, 2) ?></span></div>

            <form action="cart.php" method="post" class="checkout-form">
                <input type="text"  name="cname" placeholder="Your name"  required>
                <input type="email" name="email" placeholder="Your email" required>
                <button type="submit" name="checkout" class="btn-primary full-width btn-large">Place Order</button>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

</body>
</html>
