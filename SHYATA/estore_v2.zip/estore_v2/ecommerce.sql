-- Database: ecommerce
CREATE DATABASE IF NOT EXISTS `ecommerce` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `ecommerce`;

-- Products
CREATE TABLE IF NOT EXISTS `products` (
  `id`          int(11)        NOT NULL AUTO_INCREMENT,
  `name`        varchar(255)   NOT NULL,
  `description` text           NOT NULL,
  `price`       decimal(10,2)  NOT NULL,
  `image`       varchar(255)   DEFAULT '',
  `stock`       int(11)        NOT NULL DEFAULT 10,
  `category`    varchar(100)   DEFAULT 'General',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Orders (no user_id anymore)
CREATE TABLE IF NOT EXISTS `orders` (
  `id`         int(11)       NOT NULL AUTO_INCREMENT,
  `name`       varchar(255)  NOT NULL DEFAULT '',
  `email`      varchar(255)  NOT NULL DEFAULT '',
  `total`      decimal(10,2) NOT NULL,
  `created_at` datetime      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Order items
CREATE TABLE IF NOT EXISTS `order_items` (
  `id`         int(11)       NOT NULL AUTO_INCREMENT,
  `order_id`   int(11)       NOT NULL,
  `product_id` int(11)       NOT NULL,
  `quantity`   int(11)       NOT NULL,
  `price`      decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Admin
CREATE TABLE IF NOT EXISTS `admins` (
  `id`       int(11)      NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL UNIQUE,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default admin: admin / admin123
INSERT IGNORE INTO `admins` (`username`, `password`)
VALUES ('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Sample products
INSERT INTO `products` (`name`, `description`, `price`, `image`, `stock`, `category`) VALUES
('Wireless Headphones',  'Over-ear headphones with noise cancellation and 30h battery life. Crystal clear sound with deep bass and premium comfort ear cushions. Compatible with all Bluetooth devices.', 79.99, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=600', 15, 'Electronics'),
('Mechanical Keyboard',  'Compact TKL keyboard with RGB backlight and blue switches. N-key rollover, detachable USB-C cable, double-shot PBT keycaps for lasting durability.', 59.99, 'https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?w=600', 20, 'Electronics'),
('USB-C Hub',            '7-in-1 hub with HDMI 4K, USB 3.0 x3, SD card reader, microSD, and 100W PD charging. Plug and play, no drivers needed. Slim aluminum build.', 34.99, 'https://images.unsplash.com/photo-1587145820266-a5951ee6f620?w=600', 30, 'Accessories'),
('Webcam 1080p',         'Full HD 1080p webcam with built-in stereo mic and auto light correction. Plug and play on Windows, macOS and Linux. Wide 90° field of view, privacy cover included.', 44.99, 'https://images.unsplash.com/photo-1596742578443-7682ef5251cd?w=600', 12, 'Electronics'),
('Mouse Pad XL',         'Extra-large desk mat 80×40cm with smooth micro-textured surface and non-slip rubber base. Waterproof coating, stitched edges that never fray, fits keyboard and mouse together.', 14.99, 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=600', 50, 'Accessories'),
('LED Desk Lamp',        'Touch-control LED lamp with 3 color modes (warm/neutral/cool) and 5 brightness levels. Built-in USB charging port, memory function, 50,000h LED lifespan.', 29.99, 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=600', 25, 'Home');
