<?php
session_start();
require_once 'includes/db.php';

$success = isset($_GET['success']);
$orders  = $pdo->query("SELECT * FROM orders ORDER BY id DESC")->fetchAll();
$cart_count = array_sum($_SESSION['cart'] ?? []);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders – Estore</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<nav class="navbar">
    <a href="index.php" class="nav-logo">🛍 Estore</a>
    <div class="nav-right">
        <a href="index.php" class="nav-link">Products</a>
        <a href="cart.php" class="btn-cart">🛒 Cart <span class="cart-badge"><?= $cart_count ?></span></a>
    </div>
</nav>
<div class="nav-spacer"></div>

<div class="container">
    <h2 class="page-title">Orders</h2>

    <?php if ($success): ?>
        <p class="msg success">✓ Order placed successfully! Thank you.</p>
    <?php endif; ?>

    <?php if (empty($orders)): ?>
        <div class="empty-state">
            <p>No orders yet.</p>
            <a href="index.php" class="btn-primary">Start Shopping</a>
        </div>
    <?php else: ?>
        <?php foreach ($orders as $order): ?>
        <div class="order-card">
            <div class="order-header">
                <span><strong>Order #<?= $order['id'] ?></strong></span>
                <span><?= $order['name'] ?> · <?= $order['email'] ?></span>
                <span><?= $order['created_at'] ?></span>
                <span class="order-total">$<?= number_format($order['total'], 2) ?></span>
            </div>
            <table class="cart-table">
                <thead><tr><th>Product</th><th>Qty</th><th>Price</th></tr></thead>
                <tbody>
                <?php
                $items = $pdo->prepare("SELECT oi.*, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
                $items->execute([$order['id']]);
                foreach ($items->fetchAll() as $item):
                ?>
                    <tr>
                        <td><?= htmlspecialchars($item['name']) ?></td>
                        <td><?= $item['quantity'] ?></td>
                        <td>$<?= number_format($item['price'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

</body>
</html>
