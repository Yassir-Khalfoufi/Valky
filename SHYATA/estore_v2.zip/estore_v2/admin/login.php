<?php
session_start();
if (isset($_SESSION['admin_id'])) {
    header("Location: index.php"); exit;
}

require_once '../includes/db.php';
$error = '';

if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id']   = $admin['id'];
        $_SESSION['admin_user'] = $admin['username'];
        header("Location: index.php"); exit;
    } else {
        $error = "Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login – Estore</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>
<div class="auth-wrapper">
    <div class="auth-box">
        <h1 class="auth-logo">🔐 Admin Panel</h1>
        <p style="text-align:center;color:#888;margin-bottom:20px;font-size:13px">Estore Administration</p>
        <?php if ($error): ?><p class="msg error"><?= htmlspecialchars($error) ?></p><?php endif; ?>
        <form action="login.php" method="post">
            <input type="text"     name="username" placeholder="Username" required autofocus>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" name="login" class="btn-primary full-width">Login</button>
        </form>
        <p style="text-align:center;margin-top:16px;font-size:12px;color:#aaa">Default: admin / admin123</p>
    </div>
</div>
</body>
</html>
