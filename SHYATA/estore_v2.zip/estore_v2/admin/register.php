<?php
// ⚠ DELETE THIS FILE after creating your admin account!
session_start();
require_once '../includes/db.php';

$msg = '';
$success = false;

if (isset($_POST['create'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm  = $_POST['confirm'];

    if (strlen($username) < 3) {
        $msg = 'Username must be at least 3 characters.';
    } elseif (strlen($password) < 6) {
        $msg = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirm) {
        $msg = 'Passwords do not match.';
    } else {
        // Check if username already taken
        $check = $pdo->prepare("SELECT id FROM admins WHERE username = ?");
        $check->execute([$username]);
        if ($check->fetch()) {
            $msg = 'Username already exists.';
        } else {
            $hash = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
            $stmt->execute([$username, $hash]);
            $success = true;
        }
    }
}

// List existing admins
$admins = $pdo->query("SELECT id, username FROM admins")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Admin</title>
    <link rel="stylesheet" href="../assets/style.css">
    <style>
        .warning-banner {
            background: #fff3cd;
            border: 2px solid #ffc107;
            color: #856404;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .admin-list { margin-top: 24px; }
        .admin-list table { width: 100%; border-collapse: collapse; font-size: 14px; }
        .admin-list th, .admin-list td { padding: 10px 14px; border-bottom: 1px solid #eee; text-align: left; }
        .admin-list th { background: #f8f9fa; font-weight: 600; }
    </style>
</head>
<body>
<div class="auth-wrapper" style="flex-direction:column; gap:20px; padding: 40px 20px;">

    <div style="width:100%;max-width:420px;">
        <div class="warning-banner">
            ⚠️ <strong>Security notice:</strong> Delete this file after use!<br>
            Anyone can access it while it exists.
        </div>

        <div class="auth-box">
            <h1 class="auth-logo">➕ Create Admin</h1>

            <?php if ($success): ?>
                <p class="msg success">✓ Admin created successfully! <a href="login.php">Go to login →</a></p>
                <p style="text-align:center;font-size:13px;color:#e74c3c;margin-top:10px">
                    <strong>Now delete this file from your server.</strong>
                </p>
            <?php else: ?>
                <?php if ($msg): ?><p class="msg error"><?= htmlspecialchars($msg) ?></p><?php endif; ?>
                <form action="register.php" method="post">
                    <input type="text"     name="username" placeholder="Username (min 3 chars)" required autofocus>
                    <input type="password" name="password" placeholder="Password (min 6 chars)" required>
                    <input type="password" name="confirm"  placeholder="Confirm Password" required>
                    <button type="submit" name="create" class="btn-primary full-width">Create Admin Account</button>
                </form>
            <?php endif; ?>
        </div>

        <?php if (!empty($admins)): ?>
        <div class="admin-list auth-box" style="margin-top:16px">
            <h3 style="margin-bottom:12px;font-size:15px">Existing Admins</h3>
            <table>
                <thead><tr><th>#</th><th>Username</th></tr></thead>
                <tbody>
                <?php foreach ($admins as $a): ?>
                    <tr><td><?= $a['id'] ?></td><td><?= htmlspecialchars($a['username']) ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>

</div>
</body>
</html>
