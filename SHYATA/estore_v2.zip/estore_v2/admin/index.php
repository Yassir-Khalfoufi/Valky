<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php"); exit;
}
require_once '../includes/db.php';

// Auto-add columns that may not exist in older DB schemas
try { $pdo->query("SELECT category FROM products LIMIT 1"); }
catch (PDOException $e) { $pdo->exec("ALTER TABLE `products` ADD COLUMN `category` VARCHAR(100) NOT NULL DEFAULT 'General'"); }

try { $pdo->query("SELECT stock FROM products LIMIT 1"); }
catch (PDOException $e) { $pdo->exec("ALTER TABLE `products` ADD COLUMN `stock` INT NOT NULL DEFAULT 10"); }

// Auto-add name/email columns on orders if they don't exist
try { $pdo->query("SELECT name FROM orders LIMIT 1"); }
catch (PDOException $e) { $pdo->exec("ALTER TABLE `orders` ADD COLUMN `name` VARCHAR(255) NOT NULL DEFAULT ''"); }

try { $pdo->query("SELECT email FROM orders LIMIT 1"); }
catch (PDOException $e) { $pdo->exec("ALTER TABLE `orders` ADD COLUMN `email` VARCHAR(255) NOT NULL DEFAULT ''"); }

$msg = '';

// ── Delete product ─────────────────────────────────────────────────
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([(int)$_GET['delete']]);
    header("Location: index.php?msg=deleted"); exit;
}

// ── Add product ────────────────────────────────────────────────────
if (isset($_POST['add_product'])) {
    $name  = trim($_POST['name']);
    $desc  = trim($_POST['description']);
    $price = (float)$_POST['price'];
    $image = trim($_POST['image']);
    $stock = (int)$_POST['stock'];
    $cat   = trim($_POST['category']);

    $stmt = $pdo->prepare("INSERT INTO products (name, description, price, image, stock, category) VALUES (?,?,?,?,?,?)");
    $stmt->execute([$name, $desc, $price, $image, $stock, $cat]);
    header("Location: index.php?msg=added"); exit;
}

// ── Edit product (load for edit) ──────────────────────────────────
$edit_product = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $edit_product = $stmt->fetch();
}

// ── Save edit ─────────────────────────────────────────────────────
if (isset($_POST['save_product'])) {
    $id    = (int)$_POST['id'];
    $name  = trim($_POST['name']);
    $desc  = trim($_POST['description']);
    $price = (float)$_POST['price'];
    $image = trim($_POST['image']);
    $stock = (int)$_POST['stock'];
    $cat   = trim($_POST['category']);

    $stmt = $pdo->prepare("UPDATE products SET name=?, description=?, price=?, image=?, stock=?, category=? WHERE id=?");
    $stmt->execute([$name, $desc, $price, $image, $stock, $cat, $id]);
    header("Location: index.php?msg=updated"); exit;
}

if (isset($_GET['msg'])) {
    $msgs = ['added' => '✓ Product added.', 'updated' => '✓ Product updated.', 'deleted' => '✓ Product deleted.'];
    $msg = $msgs[$_GET['msg']] ?? '';
}

$products = $pdo->query("SELECT * FROM products ORDER BY id DESC")->fetchAll();
foreach ($products as &$p) {
    $p['category'] = $p['category'] ?? 'General';
    $p['stock']    = isset($p['stock']) ? (int)$p['stock'] : 10;
    $p['image']    = $p['image'] ?? '';
}
unset($p);
$orders   = $pdo->query("SELECT * FROM orders ORDER BY id DESC LIMIT 10")->fetchAll();
$total_orders   = $pdo->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$total_revenue  = $pdo->query("SELECT SUM(total) FROM orders")->fetchColumn();
$total_products = count($products);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin – Estore</title>
    <link rel="stylesheet" href="../assets/style.css">
    <link rel="stylesheet" href="admin.css">
</head>
<body class="admin-body">

<nav class="navbar">
    <a href="index.php" class="nav-logo">⚙ Admin Panel</a>
    <div class="nav-right">
        <span class="admin-user">👤 <?= htmlspecialchars($_SESSION['admin_user']) ?></span>
        <a href="../index.php" class="nav-link" target="_blank">View Store ↗</a>
        <a href="logout.php" class="nav-link logout">Logout</a>
    </div>
</nav>
<div class="nav-spacer"></div>

<div class="admin-container">

    <?php if ($msg): ?>
        <p class="msg success"><?= htmlspecialchars($msg) ?></p>
    <?php endif; ?>

    <!-- Stats -->
    <div class="admin-stats">
        <div class="stat-card">
            <span class="stat-num"><?= $total_products ?></span>
            <span class="stat-label">Products</span>
        </div>
        <div class="stat-card">
            <span class="stat-num"><?= $total_orders ?></span>
            <span class="stat-label">Total Orders</span>
        </div>
        <div class="stat-card">
            <span class="stat-num">$<?= number_format((float)$total_revenue, 2) ?></span>
            <span class="stat-label">Revenue</span>
        </div>
    </div>

    <!-- Tabs -->
    <div class="admin-tabs">
        <button class="admin-tab active" onclick="switchTab('products')">📦 Products</button>
        <button class="admin-tab" onclick="switchTab('orders')">🧾 Orders</button>
    </div>

    <!-- PRODUCTS TAB -->
    <div id="tab-products" class="tab-content">
        <!-- Add / Edit Form -->
        <div class="admin-card">
            <h3><?= $edit_product ? '✏ Edit Product' : '＋ Add New Product' ?></h3>
            <form action="index.php" method="post" class="product-form">
                <?php if ($edit_product): ?>
                    <input type="hidden" name="id" value="<?= $edit_product['id'] ?>">
                <?php endif; ?>
                <div class="form-grid">
                    <div class="form-group">
                        <label>Name *</label>
                        <input type="text" name="name" required
                               value="<?= htmlspecialchars($edit_product['name'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label>Category</label>
                        <input type="text" name="category" placeholder="e.g. Electronics"
                               value="<?= htmlspecialchars($edit_product['category'] ?? '') ?>">
                    </div>
                    <div class="form-group">
                        <label>Price ($) *</label>
                        <input type="number" name="price" step="0.01" min="0" required
                               value="<?= $edit_product['price'] ?? '' ?>">
                    </div>
                    <div class="form-group">
                        <label>Stock</label>
                        <input type="number" name="stock" min="0"
                               value="<?= $edit_product['stock'] ?? 10 ?>">
                    </div>
                    <div class="form-group full">
                        <label>Image URL</label>
                        <input type="text" name="image" placeholder="https://…"
                               value="<?= htmlspecialchars($edit_product['image'] ?? '') ?>">
                    </div>
                    <div class="form-group full">
                        <label>Description *</label>
                        <textarea name="description" rows="4" required><?= htmlspecialchars($edit_product['description'] ?? '') ?></textarea>
                    </div>
                </div>
                <?php if ($edit_product): ?>
                    <button type="submit" name="save_product" class="btn-primary">Save Changes</button>
                    <a href="index.php" class="btn-secondary" style="margin-left:8px">Cancel</a>
                <?php else: ?>
                    <button type="submit" name="add_product" class="btn-primary">Add Product</button>
                <?php endif; ?>
            </form>
        </div>

        <!-- Products Table -->
        <div class="admin-card">
            <h3>All Products (<?= $total_products ?>)</h3>
            <table class="admin-table">
                <thead>
                    <tr><th>ID</th><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Actions</th></tr>
                </thead>
                <tbody>
                <?php foreach ($products as $p): ?>
                <tr>
                    <td>#<?= $p['id'] ?></td>
                    <td>
                        <?php if ($p['image']): ?>
                            <img src="<?= htmlspecialchars($p['image']) ?>" alt="" class="admin-thumb">
                        <?php else: ?>
                            <div class="admin-thumb-placeholder"><?= strtoupper(substr($p['name'],0,2)) ?></div>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($p['name']) ?></td>
                    <td><?= htmlspecialchars($p['category']) ?></td>
                    <td>$<?= number_format($p['price'], 2) ?></td>
                    <td>
                        <span class="<?= $p['stock'] == 0 ? 'stock-out' : ($p['stock'] <= 5 ? 'stock-low' : 'stock-ok') ?>">
                            <?= $p['stock'] ?>
                        </span>
                    </td>
                    <td class="action-btns">
                        <a href="index.php?edit=<?= $p['id'] ?>" class="btn-edit">Edit</a>
                        <a href="index.php?delete=<?= $p['id'] ?>" class="btn-delete"
                           onclick="return confirm('Delete this product?')">Delete</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ORDERS TAB -->
    <div id="tab-orders" class="tab-content" style="display:none">
        <div class="admin-card">
            <h3>Recent Orders</h3>
            <?php if (empty($orders)): ?>
                <p style="color:#888">No orders yet.</p>
            <?php else: ?>
            <table class="admin-table">
                <thead>
                    <tr><th>ID</th><th>Customer</th><th>Email</th><th>Total</th><th>Date</th><th>Items</th></tr>
                </thead>
                <tbody>
                <?php foreach ($orders as $order): ?>
                <tr>
                    <td>#<?= $order['id'] ?></td>
                    <td><?= htmlspecialchars($order['name']) ?></td>
                    <td><?= htmlspecialchars($order['email']) ?></td>
                    <td><strong>$<?= number_format($order['total'], 2) ?></strong></td>
                    <td><?= $order['created_at'] ?></td>
                    <td>
                        <?php
                        $items = $pdo->prepare("SELECT oi.quantity, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
                        $items->execute([$order['id']]);
                        foreach ($items->fetchAll() as $it) {
                            echo '<span class="item-tag">' . htmlspecialchars($it['name']) . ' x' . $it['quantity'] . '</span>';
                        }
                        ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

</div><!-- /admin-container -->

<script>
function switchTab(tab) {
    document.querySelectorAll('.tab-content').forEach(t => t.style.display = 'none');
    document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
    document.getElementById('tab-' + tab).style.display = 'block';
    event.target.classList.add('active');
}
// Auto-open orders tab if URL says so
if (location.hash === '#orders') switchTab('orders');
</script>

</body>
</html>
