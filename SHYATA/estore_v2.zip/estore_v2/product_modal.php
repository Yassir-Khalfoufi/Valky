<?php
require_once 'includes/db.php';

$id   = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
$stmt->execute([$id]);
$p = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$p) { echo '<p style="padding:20px">Product not found.</p>'; exit; }

// Defaults for columns that may not exist in older DB schemas
$p['category'] = $p['category'] ?? 'General';
$p['stock']    = isset($p['stock']) ? (int)$p['stock'] : 10;
$p['image']    = $p['image'] ?? '';
?>
<div class="modal-product">
    <div class="modal-product-img">
        <?php if ($p['image']): ?>
            <img src="<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
        <?php else: ?>
            <div class="img-placeholder large"><?= strtoupper(substr($p['name'],0,2)) ?></div>
        <?php endif; ?>
    </div>
    <div class="modal-product-details">
        <span class="product-category-tag"><?= htmlspecialchars($p['category']) ?></span>
        <h2><?= htmlspecialchars($p['name']) ?></h2>
        <p class="modal-desc"><?= nl2br(htmlspecialchars($p['description'])) ?></p>
        <div class="modal-meta">
            <span class="price large">$<?= number_format($p['price'], 2) ?></span>
            <span class="stock-info <?= $p['stock'] > 0 ? 'in' : 'out' ?>">
                <?= $p['stock'] > 0 ? '✓ In Stock (' . $p['stock'] . ' available)' : '✗ Out of Stock' ?>
            </span>
        </div>
        <?php if ($p['stock'] > 0): ?>
        <div class="modal-actions">
            <div class="qty-selector">
                <label>Qty:</label>
                <button type="button" onclick="changeQty(-1)">−</button>
                <input type="number" id="modal-qty" value="1" min="1" max="<?= $p['stock'] ?>">
                <button type="button" onclick="changeQty(1)">+</button>
            </div>
            <button class="btn-primary btn-large"
                onclick="addToCart(<?= $p['id'] ?>, '<?= addslashes(htmlspecialchars($p['name'])) ?>', <?= $p['price'] ?>, parseInt(document.getElementById('modal-qty').value))">
                🛒 Add to Cart
            </button>
        </div>
        <?php else: ?>
            <button class="btn-primary btn-large" disabled style="opacity:.4;cursor:not-allowed;margin-top:16px">Out of Stock</button>
        <?php endif; ?>
    </div>
</div>
<script>
function changeQty(delta) {
    const input = document.getElementById('modal-qty');
    const max   = parseInt(input.max);
    let val = parseInt(input.value) + delta;
    if (val < 1)   val = 1;
    if (val > max) val = max;
    input.value = val;
}
</script>
