<?php
session_start();
require_once 'includes/db.php';

// Auto-add category column if it doesn't exist yet
try {
    $pdo->query("SELECT category FROM products LIMIT 1");
} catch (PDOException $e) {
    $pdo->exec("ALTER TABLE `products` ADD COLUMN `category` VARCHAR(100) NOT NULL DEFAULT 'General'");
}

// Auto-add stock column if it doesn't exist yet
try {
    $pdo->query("SELECT stock FROM products LIMIT 1");
} catch (PDOException $e) {
    $pdo->exec("ALTER TABLE `products` ADD COLUMN `stock` INT NOT NULL DEFAULT 10");
}

$category = isset($_GET['category']) ? $_GET['category'] : '';
$search   = isset($_GET['search'])   ? trim($_GET['search']) : '';

$where  = [];
$params = [];

if ($category) {
    $where[]  = "category = ?";
    $params[] = $category;
}
if ($search) {
    $where[]  = "(name LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql = "SELECT * FROM products";
if ($where) $sql .= " WHERE " . implode(" AND ", $where);
$sql .= " ORDER BY id DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Provide safe defaults for columns that may not exist in older DB schemas
foreach ($products as &$p) {
    $p['category'] = $p['category'] ?? 'General';
    $p['stock']    = isset($p['stock']) ? (int)$p['stock'] : 10;
    $p['image']    = $p['image'] ?? '';
}
unset($p);

$categories = $pdo->query("SELECT DISTINCT category FROM products ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);

$cart_count = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $qty) $cart_count += $qty;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estore – Products</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<!-- FIXED NAVBAR -->
<nav class="navbar">
    <a href="index.php" class="nav-logo">🛍 Estore</a>
    <div class="nav-center">
        <form action="index.php" method="GET" class="search-form">
            <?php if ($category): ?>
                <input type="hidden" name="category" value="<?= htmlspecialchars($category) ?>">
            <?php endif; ?>
            <input type="text" name="search" placeholder="Search products…" value="<?= htmlspecialchars($search) ?>">
            <button type="submit">🔍</button>
        </form>
    </div>
    <div class="nav-right">
        <a href="cart.php" class="btn-cart">🛒 Cart <span class="cart-badge"><?= $cart_count ?></span></a>
    </div>
</nav>

<!-- SPACER for fixed nav -->
<div class="nav-spacer"></div>

<div class="container">

    <!-- Category filter pills -->
    <div class="category-bar">
        <a href="index.php<?= $search ? '?search='.urlencode($search) : '' ?>" class="cat-pill <?= !$category ? 'active' : '' ?>">All</a>
        <?php foreach ($categories as $cat): ?>
            <a href="?category=<?= urlencode($cat) ?><?= $search ? '&search='.urlencode($search) : '' ?>"
               class="cat-pill <?= $category === $cat ? 'active' : '' ?>">
                <?= htmlspecialchars($cat) ?>
            </a>
        <?php endforeach; ?>
    </div>

    <h2 class="page-title">
        <?php
        if ($search)        echo 'Results for "' . htmlspecialchars($search) . '" ';
        elseif ($category)  echo htmlspecialchars($category) . ' ';
        else                echo 'Our Products ';
        ?>
        <span class="count-badge"><?= count($products) ?></span>
    </h2>

    <?php if (empty($products)): ?>
        <div class="empty-state">
            <p>No products found.</p>
            <a href="index.php" class="btn-primary">Clear filters</a>
        </div>
    <?php else: ?>
    <div class="product-grid">
        <?php foreach ($products as $p): ?>
        <div class="product-card" onclick="openProduct(<?= $p['id'] ?>)">
            <div class="product-img-wrap">
                <?php if ($p['image']): ?>
                    <img src="<?= htmlspecialchars($p['image']) ?>" alt="<?= htmlspecialchars($p['name']) ?>">
                <?php else: ?>
                    <div class="img-placeholder"><?= strtoupper(substr($p['name'],0,2)) ?></div>
                <?php endif; ?>
                <span class="product-category-tag"><?= htmlspecialchars($p['category']) ?></span>
                <?php if ($p['stock'] == 0): ?>
                    <span class="stock-tag out">Out of Stock</span>
                <?php elseif ($p['stock'] <= 5): ?>
                    <span class="stock-tag low">Only <?= $p['stock'] ?> left</span>
                <?php endif; ?>
            </div>
            <div class="product-info">
                <h3><?= htmlspecialchars($p['name']) ?></h3>
                <p class="product-desc"><?= htmlspecialchars(mb_substr($p['description'], 0, 75)) ?>…</p>
                <div class="product-footer">
                    <span class="price">$<?= number_format($p['price'], 2) ?></span>
                    <?php if ($p['stock'] > 0): ?>
                        <button class="btn-primary"
                            onclick="event.stopPropagation(); addToCart(<?= $p['id'] ?>, '<?= addslashes(htmlspecialchars($p['name'])) ?>', <?= $p['price'] ?>)">
                            Add to Cart
                        </button>
                    <?php else: ?>
                        <button class="btn-primary" disabled style="opacity:.4;cursor:not-allowed">Sold Out</button>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<!-- PRODUCT MODAL -->
<div id="modal-overlay" class="modal-overlay" onclick="closeModal(event)">
    <div class="modal-box">
        <button class="modal-close" onclick="closeModalBtn()">✕</button>
        <div id="modal-body"><div class="modal-loading">Loading…</div></div>
    </div>
</div>

<!-- TOAST -->
<div id="toast" class="toast"></div>

<script>
function openProduct(id) {
    document.getElementById('modal-overlay').classList.add('open');
    document.getElementById('modal-body').innerHTML = '<div class="modal-loading">Loading…</div>';
    fetch('product_modal.php?id=' + id)
        .then(r => r.text())
        .then(html => { document.getElementById('modal-body').innerHTML = html; });
}
function closeModal(e) {
    if (e.target === document.getElementById('modal-overlay')) closeModalBtn();
}
function closeModalBtn() {
    document.getElementById('modal-overlay').classList.remove('open');
}
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModalBtn(); });

function addToCart(id, name, price, qty) {
    qty = qty || 1;
    fetch('cart.php?action=add&id=' + id + '&name=' + encodeURIComponent(name) + '&price=' + price + '&qty=' + qty)
        .then(r => r.json())
        .then(data => {
            showToast('Added to cart!');
            document.querySelectorAll('.cart-badge').forEach(b => b.textContent = data.count);
        });
}
function showToast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    setTimeout(() => t.classList.remove('show'), 2500);
}
</script>

</body>
</html>
