-- admin_patch.sql
-- Only needed if you ALREADY ran the OLD database.sql (before this fix).
-- If you are starting fresh, just run database.sql — everything is included there.

USE vintage_store;

-- Add is_admin column if it doesn't exist yet
ALTER TABLE users
    ADD COLUMN IF NOT EXISTS is_admin TINYINT(1) NOT NULL DEFAULT 0 AFTER password;

-- Add description column if missing
ALTER TABLE products
    ADD COLUMN IF NOT EXISTS description TEXT AFTER image;

-- Fix image paths: clear all old wrong data and reload correct products
TRUNCATE TABLE products;

INSERT INTO products (category, name, price, old_price, image, slug) VALUES
-- JACKETS
('jacket', 'Vintage Batwing Oversized Jacket',                         59.50, 73.00, 'image/74d2f478-2236-448d-9b67-575679fcd332.avif', 'shop1'),
('jacket', 'Vintage Motorcycle Jacket',                                59.50, 73.00, 'image/6b05e9b5-2070-4cf4-afa1-23793249ec62.avif', 'shop2'),
('jacket', 'Women''s Vintage Brown Jacket',                            59.50, 73.00, 'image/2.avif',   'shop3'),
('jacket', 'Men''s Classic Vintage Jacket',                            59.50, 73.00, 'image/3.avif',   'shop4'),
('jacket', 'Tie-dye Print Jacket for Men',                             59.50, 73.00, 'image/4.avif',   'shop5'),
('jacket', 'Men''s Vintage Distressed Black Denim Jacket',             59.50, 73.00, 'image/5.avif',   'shop6'),
('jacket', 'Men''s Retro Washed Denim Jacket',                         59.50, 73.00, 'image/7.avif',   'shop7'),
('jacket', 'Men''s New Washed Blue Denim Jacket',                      59.50, 73.00, 'image/8.avif',   'shop8'),
-- PANTS
('pants', 'Men''s Vintage Washed Blue Jeans',                          59.50, 73.00, 'image/1.1.avif', 'shop1'),
('pants', 'Loose Wide-Leg Jeans with Floral Embroidery',               59.50, 73.00, 'image/1.2.avif', 'shop2'),
('pants', 'Straight Loose Men''s Jeans',                               59.50, 73.00, 'image/1.3.avif', 'shop3'),
('pants', 'Men''s Pure Cotton Straight-Leg Loose-Fit Casual Pants',    59.50, 73.00, 'image/1.4.avif', 'shop4'),
('pants', 'American High Street Vintage Washed Graffiti Jeans',        59.50, 73.00, 'image/1.5.avif', 'shop5'),
('pants', 'Men''s Fashion Vintage Wide-Leg Casual Pants',              59.50, 73.00, 'image/1.6.avif', 'shop6'),
('pants', 'Vintage Daisy Print Wide-Leg Work Pants',                   59.50, 73.00, 'image/1.7.avif', 'shop7'),
('pants', 'Men''s Heavy-Duty Vintage Washed Jeans',                    59.50, 73.00, 'image/1.8.avif', 'shop8'),
-- HOODIES
('hoodie', 'Y2K Unisex Retro Hoodie',                                  59.50, 73.00, 'image/2.1.avif', 'shop1'),
('hoodie', 'Sweatshirt with Bold Vintage Print',                       59.50, 73.00, 'image/2.2.avif', 'shop2'),
('hoodie', 'Oversized Vintage Graphic Sweatshirt',                     59.50, 73.00, 'image/2.3.avif', 'shop3'),
('hoodie', 'Hooded Loose Casual Sweatshirt',                           59.50, 73.00, 'image/2.4.avif', 'shop4'),
('hoodie', 'Vintage Dollar Bill Print Hooded Sweatshirt',              59.50, 73.00, 'image/2.5.avif', 'shop5'),
('hoodie', 'Gothic Portrait Print Pullover',                           59.50, 73.00, 'image/2.6.avif', 'shop6'),
('hoodie', 'Women''s Y2K Retro Graphic Sweater',                       59.50, 73.00, 'image/2.7.avif', 'shop7'),
('hoodie', 'Men''s American Vintage Double Zipper Hoodie',             59.50, 73.00, 'image/2.8.avif', 'shop8'),
-- SHOES
('shoes', 'Couple''s Versatile Trendy Sports Casual Shoes',            59.50, 73.00, 'image/3.1.avif', 'shop1'),
('shoes', 'Unisex Vintage Skate Shoes Anti-Slip Thick Sole',           59.50, 73.00, 'image/3.2.avif', 'shop2'),
('shoes', 'Men''s Casual Retro Lace-Up Loafers',                       59.50, 73.00, 'image/3.3.avif', 'shop3'),
('shoes', 'Men''s Lightweight Mid-Calf Hiking Boots',                  59.50, 73.00, 'image/3.4.avif', 'shop4'),
('shoes', 'Women''s Vintage Sneakers',                                 59.50, 73.00, 'image/3.5.avif', 'shop5'),
('shoes', 'Four Seasons Outdoor Women''s Fashion Shoes',               59.50, 73.00, 'image/3.6.avif', 'shop6'),
('shoes', 'Jifffly Classic American Graffiti Sneakers',                59.50, 73.00, 'image/3.7.avif', 'shop7'),
('shoes', 'Derby Shoes Spring Low-Top Men''s Vintage',                 59.50, 73.00, 'image/3.8.avif', 'shop8');

-- Set admin flag on existing admin user
UPDATE users SET is_admin = 1 WHERE username = 'admin';
